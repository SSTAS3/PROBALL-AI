# PROBALL AI

Початкова Android-версія українською мовою.

## Що працює в цій версії
- Завантаження майбутніх футбольних матчів через Cloudflare Worker.
- Назви турнірів, команд і час початку матчу.
- Ручне оновлення списку матчів.
- Пояснення щодо аналітики без вигаданих відсотків.
- Без live-рахунків.

## Джерело даних
`https://divine-brook-f515.leskolesko99.workers.dev/matches`

Cloudflare Worker має використовувати секрет `FOOTBALL_DATA_TOKEN` для запитів до football-data.org.

## Збірка
Android Gradle Plugin 8.7.3, compile SDK 35, Java без сторонніх бібліотек.
Проєкт можна завантажити в GitHub і зібрати за допомогою Android SDK/Gradle. Якщо ваш GitHub Actions workflow розрахований на іншу структуру архіву, спершу перевірте крок розпакування.
