plugins {
    id("com.android.application")
}

android {
    namespace = "com.smartbetpro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartbetpro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.0"
    }
}
