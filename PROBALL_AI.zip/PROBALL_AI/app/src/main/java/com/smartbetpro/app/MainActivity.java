package com.smartbetpro.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private static final String API_URL = "https://divine-brook-f515.leskolesko99.workers.dev/matches";
    private LinearLayout matchList;
    private TextView status;
    private Button refreshButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        loadMatches();
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10, 17, 32));
        root.setPadding(dp(18), dp(18), dp(18), dp(12));

        TextView brand = new TextView(this);
        brand.setText("PROBALL AI"); brand.setTextColor(Color.rgb(69, 220, 160));
        brand.setTextSize(29); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("Футбол • майбутні матчі та аналітика");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(15);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.bottomMargin = dp(12);
        root.addView(subtitle, sp);

        refreshButton = new Button(this); refreshButton.setText("ОНОВИТИ МАТЧІ");
        refreshButton.setOnClickListener(v -> loadMatches()); root.addView(refreshButton);

        status = new TextView(this); status.setText("Завантаження матчів…");
        status.setTextColor(Color.WHITE); status.setTextSize(14);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2); stp.topMargin = dp(8); stp.bottomMargin = dp(8);
        root.addView(status, stp);

        ScrollView scroll = new ScrollView(this);
        matchList = new LinearLayout(this); matchList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(matchList); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView footer = new TextView(this); footer.setText("Дані: football-data.org • Без live-рахунків");
        footer.setTextColor(Color.GRAY); footer.setTextSize(11); footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(8); root.addView(footer, fp);
        setContentView(root);
    }

    private void loadMatches() {
        refreshButton.setEnabled(false); status.setText("Завантажуємо майбутні матчі…"); matchList.removeAllViews();
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection)new URL(API_URL).openConnection();
                connection.setRequestMethod("GET"); connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
                connection.setRequestProperty("Accept", "application/json");
                int code = connection.getResponseCode();
                InputStream stream = (code >= 200 && code < 300) ? connection.getInputStream() : connection.getErrorStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                StringBuilder body = new StringBuilder(); String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();
                if (code < 200 || code >= 300) throw new Exception("Помилка сервера: " + code);
                JSONObject json = new JSONObject(body.toString());
                JSONArray matches = json.optJSONArray("matches");
                if (matches == null) throw new Exception("У відповіді сервера немає списку матчів");
                runOnUiThread(() -> showMatches(matches));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Невідома помилка" : e.getMessage();
                runOnUiThread(() -> { status.setText("Не вдалося завантажити матчі. Перевір інтернет і натисни «ОНОВИТИ МАТЧІ».\n" + message); refreshButton.setEnabled(true); });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void showMatches(JSONArray matches) {
        matchList.removeAllViews();
        if (matches.length() == 0) { status.setText("Майбутніх матчів не знайдено."); refreshButton.setEnabled(true); return; }
        status.setText("Знайдено матчів: " + matches.length());
        for (int i = 0; i < matches.length(); i++) {
            JSONObject m = matches.optJSONObject(i); if (m == null) continue;
            JSONObject c = m.optJSONObject("competition"), h = m.optJSONObject("homeTeam"), a = m.optJSONObject("awayTeam");
            addMatchCard(c == null ? "Турнір" : c.optString("name", "Турнір"),
                h == null ? "Господарі" : h.optString("name", "Господарі"),
                a == null ? "Гості" : a.optString("name", "Гості"), formatDate(m.optString("utcDate", "")));
        }
        refreshButton.setEnabled(true);
    }

    private String formatDate(String raw) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US); in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = in.parse(raw); SimpleDateFormat out = new SimpleDateFormat("dd.MM.yyyy • HH:mm", new Locale("uk", "UA"));
            out.setTimeZone(TimeZone.getDefault()); return out.format(date);
        } catch (Exception e) { return raw; }
    }

    private void addMatchCard(String league, String home, String away, String date) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12)); card.setBackgroundColor(Color.rgb(22, 32, 51));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(10); card.setLayoutParams(cp);
        TextView l = new TextView(this); l.setText(league.toUpperCase(new Locale("uk", "UA"))); l.setTextColor(Color.rgb(69,220,160)); l.setTextSize(11); l.setTypeface(Typeface.DEFAULT, Typeface.BOLD); card.addView(l);
        TextView teams = new TextView(this); teams.setText(home + "\nvs\n" + away); teams.setTextColor(Color.WHITE); teams.setTextSize(17); teams.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2); tp.topMargin = dp(7); card.addView(teams, tp);
        TextView d = new TextView(this); d.setText(date); d.setTextColor(Color.LTGRAY); d.setTextSize(13);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2); dp.topMargin = dp(7); card.addView(d, dp);
        Button b = new Button(this); b.setText("АНАЛІЗ МАТЧУ"); b.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
            .setTitle("Аналіз матчу").setMessage(home + " — " + away + "\n\nЦя версія показує розклад матчів. Для надійних відсотків 1X2, тоталу та «обидві заб'ють» потрібна перевірена статистика команд. Вигадані прогнози не показуються.")
            .setPositiveButton("Зрозуміло", null).show());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(5); card.addView(b, bp);
        matchList.addView(card);
    }
}
